# momottakr 法律文档网站

应用 Bundle ID 为 `com.momottakr.mmttLedger`。网站包含英文原文和中文逐节释义。当前生效日期为 2026 年 11 月 9 日。

| 文档 | 英文文件 | 中文文件 |
| --- | --- | --- |
| 隐私政策 | `privacy/index.html` | `zh/privacy/index.html` |
| 用户协议 | `terms/index.html` | `zh/terms/index.html` |

## 发布

1. 将压缩包解压后的**内容**提交到 `gitchen666/momottakr` 仓库的 `main` 分支根目录，保留目录层级及 `.nojekyll`。
2. 在仓库的 **Settings → Pages** 中，将 **Source** 设为 **Deploy from a branch**，选择 `main` 和 `/ (root)`，然后保存。
3. 发布成功后，检查 [主页](https://gitchen666.github.io/momottakr/)、[隐私政策](https://gitchen666.github.io/momottakr/privacy/)和[用户协议](https://gitchen666.github.io/momottakr/terms/)。

## 更新

在 GitHub 打开对应的 HTML 文件并编辑正文。修订生效日期时，在对应的中英文页面同步更新 `<time>` 的文字和 `datetime` 属性。提交后由 GitHub Pages 自动重新发布，公开链接保持固定，历史版本保存在仓库提交记录中。

## 本地预览

把解压后的目录命名为 `momottakr`，在它的上一级目录运行静态 HTTP 服务，例如 `python -m http.server 8000`。打开 `http://localhost:8000/momottakr/`。
